#!/bin/sh
exec kore-exec \
    definition.kore \
    --pattern pgm.kore \
    --output result.kore \
    --module TYCK \
    --smt-timeout 40 \
    --smt z3 \
    --strategy any \
    --log-level \
    warning \
    --enable-log-timestamps \
    "$@"
